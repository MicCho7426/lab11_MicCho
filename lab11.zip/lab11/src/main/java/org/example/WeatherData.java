package org.example;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class WeatherData implements Subject {
    private float temperature;
    private float humidity;
    private float pressure;
    private List<Observer> observers = new ArrayList<>();
    private HttpClient client = HttpClient.newHttpClient();
    private Gson gson = new Gson();

    public WeatherData() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(this::fetchWeatherData, 0, 15, TimeUnit.MINUTES);
    }

    private void fetchWeatherData() {
        try {
            URI uri = new URI("https://api.openweathermap.org/data/2.5/weather?q=Wroclaw,pl&appid=d18f71beb43d4c20651ce8f95fcb5e3a&units=metric");
            HttpRequest request = HttpRequest.newBuilder(uri)
                    .header("Accept", "application/json")
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            JsonObject jsonResponse = gson.fromJson(response.body(), JsonObject.class);
            temperature = jsonResponse.getAsJsonObject("main").get("temp").getAsFloat();
            humidity = jsonResponse.getAsJsonObject("main").get("humidity").getAsFloat();
            pressure = jsonResponse.getAsJsonObject("main").get("pressure").getAsFloat();

            measurementChanged();
        } catch (IOException | InterruptedException | java.net.URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public void measurementChanged() {
        notifyObserver();
    }

    @Override
    public void registerObserver(Observer o) {
        if (!observers.contains(o)) observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObserver() {
        for (Observer o : observers) {
            o.update(temperature, humidity, pressure);
        }
    }
}