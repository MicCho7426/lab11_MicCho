package org.example;

public interface Display {

    void display();
}