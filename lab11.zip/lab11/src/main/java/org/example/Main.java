package org.example;

public class Main {
    public static void main(String[] args) {
        WeatherData weatherData = new WeatherData();
        CurrentWeatherDisplay currentWeatherDisplay = new CurrentWeatherDisplay();
        weatherData.registerObserver(currentWeatherDisplay);
    }
}